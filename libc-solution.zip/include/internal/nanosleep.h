#ifndef __NANOSLEEP_H__
#define __NANOSLEEP_H__
int nanosleep(const struct timespec *t1, struct timespec *t2);
#endif
